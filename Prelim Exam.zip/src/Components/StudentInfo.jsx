import React from 'react';

const StudentInfo = () => {
    const name = "Cruz, Ma. Erica J";
    const section = "BSIT 3B";

    return (
        <div style={{ padding: '10px', backgroundColor: '#f9f9f9', borderBottom: '1px solid #ddd' }}>
            <h2>Welcome, {name}!</h2>
            <p>Section: {section}</p>
        </div>
    );
};

export default StudentInfo;