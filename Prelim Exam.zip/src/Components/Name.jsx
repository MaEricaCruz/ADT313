import React from 'react'

function Prelim(){
  const styles = {
    container: {
      textAlign: 'center',
      fontFamily: 'Arial, sans-serif',
      marginTop: '50px',
    },
    header: {
      fontSize: '40px',
      color: '#000000',
    },
    paragraph: {
      fontSize: '20px',
      color: '#34495e',
    }
  };

    return(
        <div style={styles.container}>
             <h1 style={styles.header}>Ma. Erica J. Cruz</h1>
             <p style={styles.paragraph}>BSIT - 3B</p>
        </div>
    )
 }

export default Prelim;


