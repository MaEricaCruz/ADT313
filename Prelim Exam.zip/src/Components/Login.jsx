import React, { useState, useEffect } from "react";
import './LoginForm.css'; 

const AuthForm = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignup, setIsSignup] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [theme, setTheme] = useState("light");

  const handleAuth = (e) => {
    e.preventDefault();
    if (isSignup) {
      console.log("Signup email:", email, "password:", password);
    } else {
      console.log("Login email:", email, "password:", password);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  }

  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === "light" ? "dark" : "light"));
    localStorage.setItem('theme', theme === "light" ? "dark" : "light");
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      setTheme(savedTheme);
    }
  }, []);

  return (
    <div className={`container ${theme}`}>
      <div className="header">
        <h2 className="text">{isSignup ? "Signup" : "Login"}</h2>
        <div className="auth-toggle">
          <span 
            className={`auth-link ${!isSignup ? "active" : ""}`} 
            onClick={() => setIsSignup(false)}
          >
            Login
          </span>
          <span 
            className={`auth-link ${isSignup ? "active" : ""}`} 
            onClick={() => setIsSignup(true)}
          >
            Signup
          </span>
        </div>
      </div>
      <form onSubmit={handleAuth}>
        <div className="inputs">
          {isSignup && (
            <div className="input">
              <input
                type="text"
                placeholder="Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required={isSignup}
                className="input-inner"
              />
            </div>
          )}
          <div className="input">
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="input-inner"
            />
          </div>
          <div className="input">
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="input-inner"
            />
          </div>       
    <div>
    
    </div>
    
        </div>
        <div className="submit-container">
          <button type="submit" className="submit">{isSignup ? "Signup" : "Login"}</button>
        </div>
        <div className="register-link">
          {isSignup ? (
            <p>Already have an account? <span className="auth-link" onClick={() => setIsSignup(false)}>Login</span></p>
          ) : (
            <p>Don't have an account? <span className="auth-link" onClick={() => setIsSignup(true)}>Register</span></p>
          )}
        </div>
        <div className="theme-switcher">
          <button type="button" onClick={toggleTheme}>
            Switch to {theme === "light" ? "Dark" : "Light"} Theme
          </button>
        </div>
      </form>
    </div>
  );
};

export default AuthForm;
