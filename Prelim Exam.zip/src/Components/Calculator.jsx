import React, { useState } from 'react';
import './Calculator.css';

   function Calculator() {
     const [num1, setNum1] = useState(0);
     const [num2, setNum2] = useState(0);
     const [result, setResult] = useState(0);

 const calculate = (operation) => {
   let total = 0;
   
   switch (operation) {
     case 'Addition':
       total = parseFloat(num1) + parseFloat(num2);
       break;
     case 'Substraction':
       total = parseFloat(num1) - parseFloat(num2);
       break;
     case 'Multiplication':
       total = parseFloat(num1) * parseFloat(num2);
       break;
     case 'Division':
       total = parseFloat(num1) / parseFloat(num2);
       break;
     default:
       break;
   }

   setResult(total);
 };

 return (
   <div style={{ padding: '50px' }}>
     <input 
       type="number" 
       value={num1} 
       onChange={(e) => setNum1(e.target.value)} 
       placeholder="Enter number 1" 
     />
     <input 
       type="number" 
       value={num2} 
       onChange={(e) => setNum2(e.target.value)} 
       placeholder="Enter number 2" 
     />
     <input
       value={result}
     />
     <div classname= 'buttons'>
       <button onClick={() => calculate('Addition')}>Addition</button>
       <button onClick={() => calculate('Substraction')}>Substraction</button>
       <button onClick={() => calculate('Multiplication')}>Multiplication</button>
       <button onClick={() => calculate('Division')}>Division</button>
     </div>
   </div>
 );
}

export default Calculator;
