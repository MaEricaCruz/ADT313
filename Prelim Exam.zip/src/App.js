import React from "react";
import './App.css';
import Name from './Components/Name'
import Login from './Components/Login'
import Calculator from './Components/Calculator'
import Profile from "./Components/Profile";



function App() {
  return (
      <div className="App">
      <Name />
      <Login />
      <Calculator />
      <Profile />
  
      </div>
  );
}

export default App;
